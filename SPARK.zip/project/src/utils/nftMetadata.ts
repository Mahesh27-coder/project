import { PassportData, VisaData, HealthRecordData, NFTMetadata } from '../types/nft';

export const createPassportMetadata = (data: PassportData): NFTMetadata => ({
  name: `Digital Passport - ${data.fullName}`,
  description: `Official digital passport for ${data.fullName}`,
  image: `https://images.unsplash.com/photo-1544427920-c49ccfb85579?auto=format&fit=crop&q=80&w=1000`,
  attributes: [
    { trait_type: 'Document Type', value: 'Passport' },
    { trait_type: 'Full Name', value: data.fullName },
    { trait_type: 'Date of Birth', value: data.dateOfBirth },
    { trait_type: 'Nationality', value: data.nationality },
    { trait_type: 'Passport Number', value: data.passportNumber },
    { trait_type: 'Issue Date', value: data.issueDate },
    { trait_type: 'Expiry Date', value: data.expiryDate },
    { trait_type: 'Gender', value: data.gender },
    { trait_type: 'Place of Birth', value: data.placeOfBirth }
  ]
});

export const createVisaMetadata = (data: VisaData): NFTMetadata => ({
  name: `Digital Visa - ${data.country}`,
  description: `Official digital visa for ${data.country}`,
  image: `https://images.unsplash.com/photo-1569098644584-210bcd375b59?auto=format&fit=crop&q=80&w=1000`,
  attributes: [
    { trait_type: 'Document Type', value: 'Visa' },
    { trait_type: 'Visa Type', value: data.visaType },
    { trait_type: 'Country', value: data.country },
    { trait_type: 'Duration', value: data.duration },
    { trait_type: 'Entries', value: data.entries },
    { trait_type: 'Valid From', value: data.validFrom },
    { trait_type: 'Valid Until', value: data.validUntil },
    { trait_type: 'Visa Number', value: data.visaNumber },
    { trait_type: 'Purpose', value: data.purpose }
  ]
});

export const createHealthRecordMetadata = (data: HealthRecordData): NFTMetadata => ({
  name: 'Digital Health Record',
  description: 'Official digital health record for international travel',
  image: `https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=1000`,
  attributes: [
    { trait_type: 'Document Type', value: 'Health Record' },
    { trait_type: 'Blood Type', value: data.bloodType },
    { trait_type: 'Last Checkup', value: data.lastCheckup },
    { trait_type: 'Vaccination Count', value: data.vaccinations.length },
    ...data.vaccinations.map((v, i) => ({
      trait_type: `Vaccination ${i + 1}`,
      value: `${v.name} (Valid until: ${v.validUntil})`
    })),
    { trait_type: 'Allergies', value: data.allergies.join(', ') || 'None' },
    { trait_type: 'Medical Conditions', value: data.medicalConditions.join(', ') || 'None' }
  ]
});