const uploadToIPFS = async (metadata: any) => {
  // For demo purposes, we'll return a mock IPFS hash
  // In production, implement actual IPFS upload
  return `ipfs://QmXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXx`;
};