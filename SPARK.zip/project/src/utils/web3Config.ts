import { ethers } from 'ethers';
import TravelNFTAbi from '../contracts/TravelNFT.json';

export const TRAVEL_NFT_ADDRESS = '0x1234567890123456789012345678901234567890'; // Replace with your deployed contract address
export const SEPOLIA_CHAIN_ID = '0xaa36a7'; // Chain ID for Sepolia testnet
export const SEPOLIA_RPC_URL = 'https://sepolia.infura.io/v3/YOUR_INFURA_KEY'; // Replace with your Infura key

export const SEPOLIA_NETWORK_PARAMS = {
  chainId: SEPOLIA_CHAIN_ID,
  chainName: 'Sepolia Test Network',
  nativeCurrency: {
    name: 'Sepolia ETH',
    symbol: 'SEP',
    decimals: 18,
  },
  rpcUrls: ['https://sepolia.infura.io/v3/YOUR_INFURA_KEY'],
  blockExplorerUrls: ['https://sepolia.etherscan.io'],
};

export const switchToSepoliaNetwork = async () => {
  if (!window.ethereum) throw new Error('Please install MetaMask');
  
  try {
    // Try to switch to Sepolia network
    await window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: SEPOLIA_CHAIN_ID }],
    });
  } catch (switchError: any) {
    // If the network doesn't exist, add it
    if (switchError.code === 4902) {
      try {
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [SEPOLIA_NETWORK_PARAMS],
        });
      } catch (addError) {
        throw new Error('Failed to add Sepolia network');
      }
    } else {
      throw switchError;
    }
  }
};

export const getWeb3Provider = async () => {
  if (!window.ethereum) {
    throw new Error('Please install MetaMask');
  }

  await switchToSepoliaNetwork();
  return new ethers.providers.Web3Provider(window.ethereum);
};

export const getTravelNFTContract = (provider: ethers.providers.Web3Provider) => {
  const signer = provider.getSigner();
  return new ethers.Contract(TRAVEL_NFT_ADDRESS, TravelNFTAbi.abi, signer);
};