import { useState } from 'react';
import { ethers } from 'ethers';
import { getTravelNFTContract } from '../utils/web3Config';

export const useNFTMinting = () => {
  const [minting, setMinting] = useState(false);

  const mintNFT = async (
    provider: ethers.providers.Web3Provider,
    recipientAddress: string,
    documentType: string,
    metadata: any
  ) => {
    try {
      setMinting(true);
      const contract = getTravelNFTContract(provider);
      const tx = await contract.mintTravelDocument(
        recipientAddress,
        metadata.uri,
        documentType
      );
      await tx.wait();
      return tx.hash;
    } catch (error) {
      console.error('Error minting NFT:', error);
      throw error;
    } finally {
      setMinting(false);
    }
  };

  return { mintNFT, minting };
};