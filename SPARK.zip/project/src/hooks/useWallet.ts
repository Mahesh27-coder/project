import { useState, useCallback } from 'react';
import { ethers } from 'ethers';
import { getWeb3Provider, SEPOLIA_CHAIN_ID } from '../utils/web3Config';

export const useWallet = () => {
  const [account, setAccount] = useState<string>('');
  const [connected, setConnected] = useState(false);
  const [networkError, setNetworkError] = useState<string | null>(null);

  const checkNetwork = async (provider: ethers.providers.Web3Provider) => {
    const network = await provider.getNetwork();
    const chainIdHex = `0x${network.chainId.toString(16)}`;
    return chainIdHex === SEPOLIA_CHAIN_ID;
  };

  const connect = useCallback(async () => {
    try {
      setNetworkError(null);
      const provider = await getWeb3Provider();
      
      const isCorrectNetwork = await checkNetwork(provider);
      if (!isCorrectNetwork) {
        setNetworkError('Please switch to Sepolia Test Network');
        return null;
      }

      const accounts = await provider.send('eth_requestAccounts', []);
      setAccount(accounts[0]);
      setConnected(true);
      return provider;
    } catch (error: any) {
      console.error('Error connecting wallet:', error);
      setNetworkError(error.message);
      throw error;
    }
  }, []);

  return { account, connected, connect, networkError };
};