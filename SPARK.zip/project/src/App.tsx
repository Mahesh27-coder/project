import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import GovernmentPortal from './components/GovernmentPortal';
import CitizenPortal from './components/CitizenPortal';
import BiometricPortal from './components/BiometricPortal';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<GovernmentPortal />} />
            <Route path="/citizen" element={<CitizenPortal />} />
            <Route path="/biometric" element={<BiometricPortal />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;