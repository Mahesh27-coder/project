import React from 'react';
import { Link } from 'react-router-dom';
import { Globe, User, Fingerprint } from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="bg-blue-600 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Globe className="h-8 w-8" />
            <span className="font-bold text-xl">TravelChain</span>
          </Link>
          <div className="flex space-x-4">
            <Link to="/" className="flex items-center space-x-1 hover:text-blue-200">
              <User className="h-5 w-5" />
              <span>Government</span>
            </Link>
            <Link to="/citizen" className="flex items-center space-x-1 hover:text-blue-200">
              <User className="h-5 w-5" />
              <span>Citizen</span>
            </Link>
            <Link to="/biometric" className="flex items-center space-x-1 hover:text-blue-200">
              <Fingerprint className="h-5 w-5" />
              <span>Biometric</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;