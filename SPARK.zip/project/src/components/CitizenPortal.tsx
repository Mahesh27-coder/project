import React, { useState } from 'react';
import { Wallet, FileText } from 'lucide-react';

const CitizenPortal = () => {
  const [connected, setConnected] = useState(false);
  const [nfts, setNfts] = useState([
    { id: 1, type: 'Passport', issueDate: '2024-03-15' },
    { id: 2, type: 'Visa', issueDate: '2024-03-15' },
    { id: 3, type: 'Health Records', issueDate: '2024-03-15' }
  ]);

  const connectWallet = async () => {
    // Web3 wallet connection would go here
    setConnected(true);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Citizen NFT Portal</h2>
          <button
            onClick={connectWallet}
            className={`flex items-center space-x-2 px-4 py-2 rounded ${
              connected ? 'bg-green-600' : 'bg-blue-600'
            } text-white`}
          >
            <Wallet className="h-5 w-5" />
            <span>{connected ? 'Connected' : 'Connect Wallet'}</span>
          </button>
        </div>

        {connected && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {nfts.map((nft) => (
                <div key={nft.id} className="p-6 border rounded-lg shadow-md">
                  <div className="flex items-center space-x-2 mb-4">
                    <FileText className="h-6 w-6 text-blue-600" />
                    <h3 className="font-semibold">{nft.type} NFT</h3>
                  </div>
                  <p className="text-sm text-gray-600">Issue Date: {nft.issueDate}</p>
                  <button className="mt-4 w-full bg-blue-100 text-blue-600 px-4 py-2 rounded hover:bg-blue-200">
                    View Details
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CitizenPortal;