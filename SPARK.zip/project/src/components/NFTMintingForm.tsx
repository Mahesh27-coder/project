import React, { useState } from 'react';
import PassportForm from './forms/PassportForm';
import VisaForm from './forms/VisaForm';
import HealthRecordForm from './forms/HealthRecordForm';
import { createPassportMetadata, createVisaMetadata, createHealthRecordMetadata } from '../utils/nftMetadata';
import { PassportData, VisaData, HealthRecordData } from '../types/nft';

interface Props {
  onMint: (metadata: any) => Promise<void>;
  documentType: string;
}

const NFTMintingForm: React.FC<Props> = ({ onMint, documentType }) => {
  const handlePassportSubmit = async (data: PassportData) => {
    const metadata = createPassportMetadata(data);
    await onMint(metadata);
  };

  const handleVisaSubmit = async (data: VisaData) => {
    const metadata = createVisaMetadata(data);
    await onMint(metadata);
  };

  const handleHealthRecordSubmit = async (data: HealthRecordData) => {
    const metadata = createHealthRecordMetadata(data);
    await onMint(metadata);
  };

  return (
    <div className="mt-6">
      {documentType === 'Passport' && <PassportForm onSubmit={handlePassportSubmit} />}
      {documentType === 'Visa' && <VisaForm onSubmit={handleVisaSubmit} />}
      {documentType === 'Health Records' && <HealthRecordForm onSubmit={handleHealthRecordSubmit} />}
    </div>
  );
};

export default NFTMintingForm;