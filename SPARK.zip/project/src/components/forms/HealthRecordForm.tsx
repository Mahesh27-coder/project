import React from 'react';
import { HealthRecordData } from '../../types/nft';

interface Props {
  onSubmit: (data: HealthRecordData) => void;
}

const HealthRecordForm: React.FC<Props> = ({ onSubmit }) => {
  const [formData, setFormData] = React.useState<HealthRecordData>({
    vaccinations: [],
    bloodType: '',
    allergies: [],
    medicalConditions: [],
    lastCheckup: '',
  });

  const [newVaccination, setNewVaccination] = React.useState({
    name: '',
    date: '',
    validUntil: '',
  });

  const addVaccination = () => {
    if (newVaccination.name && newVaccination.date && newVaccination.validUntil) {
      setFormData({
        ...formData,
        vaccinations: [...formData.vaccinations, newVaccination],
      });
      setNewVaccination({ name: '', date: '', validUntil: '' });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Vaccinations</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            type="text"
            placeholder="Vaccination Name"
            className="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={newVaccination.name}
            onChange={(e) => setNewVaccination({ ...newVaccination, name: e.target.value })}
          />
          <input
            type="date"
            className="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={newVaccination.date}
            onChange={(e) => setNewVaccination({ ...newVaccination, date: e.target.value })}
          />
          <div className="flex space-x-2">
            <input
              type="date"
              className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              value={newVaccination.validUntil}
              onChange={(e) => setNewVaccination({ ...newVaccination, validUntil: e.target.value })}
            />
            <button
              type="button"
              onClick={addVaccination}
              className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
            >
              Add
            </button>
          </div>
        </div>

        {formData.vaccinations.length > 0 && (
          <div className="mt-4">
            <h4 className="text-sm font-medium mb-2">Added Vaccinations:</h4>
            <ul className="space-y-2">
              {formData.vaccinations.map((v, index) => (
                <li key={index} className="text-sm">
                  {v.name} - Date: {v.date} - Valid until: {v.validUntil}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Blood Type</label>
          <select
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.bloodType}
            onChange={(e) => setFormData({ ...formData, bloodType: e.target.value })}
          >
            <option value="">Select Blood Type</option>
            {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((type) => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Last Checkup Date</label>
          <input
            type="date"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.lastCheckup}
            onChange={(e) => setFormData({ ...formData, lastCheckup: e.target.value })}
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Allergies (comma-separated)</label>
        <input
          type="text"
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.allergies.join(', ')}
          onChange={(e) => setFormData({ ...formData, allergies: e.target.value.split(',').map(s => s.trim()) })}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Medical Conditions (comma-separated)</label>
        <input
          type="text"
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.medicalConditions.join(', ')}
          onChange={(e) => setFormData({ ...formData, medicalConditions: e.target.value.split(',').map(s => s.trim()) })}
        />
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Generate Health Record NFT
        </button>
      </div>
    </form>
  );
};

export default HealthRecordForm;