import React, { useState } from 'react';
import { Shield, AlertCircle } from 'lucide-react';
import { useWallet } from '../hooks/useWallet';
import { useNFTMinting } from '../hooks/useNFTMinting';
import { getWeb3Provider } from '../utils/web3Config';
import NFTMintingForm from './NFTMintingForm';

const GovernmentPortal = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const { connect, connected, account, networkError } = useWallet();
  const { mintNFT, minting } = useNFTMinting();
  const [selectedDocumentType, setSelectedDocumentType] = useState<string>('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.username === 'tarun' && formData.password === '12345') {
      setIsLoggedIn(true);
      connect().catch(console.error);
    } else {
      alert('Invalid credentials');
    }
  };

  const handleMintNFT = async (metadata: any) => {
    if (!connected) {
      alert('Please connect your wallet first');
      return;
    }

    try {
      const provider = await getWeb3Provider();
      const txHash = await mintNFT(provider, account, selectedDocumentType, metadata);
      alert(`Successfully minted ${selectedDocumentType} NFT on Sepolia! Transaction: ${txHash}`);
      setSelectedDocumentType('');
    } catch (error) {
      console.error('Error:', error);
      alert('Error minting NFT. Please check console for details.');
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="max-w-md mx-auto mt-10 bg-white p-8 rounded-lg shadow-md">
        <div className="flex items-center justify-center mb-6">
          <Shield className="h-12 w-12 text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold text-center mb-6">Government Official Login</h2>
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Username</label>
            <input
              type="text"
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Password</label>
            <input
              type="password"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Login
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-xl p-6">
        <h2 className="text-2xl font-bold mb-6">NFT Minting Portal (Sepolia Testnet)</h2>
        {networkError && (
          <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-lg flex items-center">
            <AlertCircle className="h-5 w-5 mr-2" />
            {networkError}
          </div>
        )}
        {connected ? (
          <>
            <div className="mb-6">
              <p className="text-sm text-gray-600">Connected Account: {account}</p>
              <p className="text-sm text-green-600">Network: Sepolia Test Network</p>
            </div>
            {!selectedDocumentType ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {['Passport', 'Visa', 'Health Records'].map((type) => (
                  <div key={type} className="p-4 border rounded-lg">
                    <h3 className="font-semibold mb-2">{type} NFT</h3>
                    <button
                      onClick={() => setSelectedDocumentType(type)}
                      className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                    >
                      Create {type} NFT
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-semibold">{selectedDocumentType} NFT Creation</h3>
                  <button
                    onClick={() => setSelectedDocumentType('')}
                    className="text-gray-600 hover:text-gray-800"
                  >
                    Back to Selection
                  </button>
                </div>
                <NFTMintingForm
                  onMint={handleMintNFT}
                  documentType={selectedDocumentType}
                />
              </div>
            )}
          </>
        ) : (
          <div className="text-center">
            <button
              onClick={() => connect()}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
            >
              Connect to Sepolia
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default GovernmentPortal;