import React, { useState, useEffect } from 'react';
import { Fingerprint, Shield, Check, AlertCircle } from 'lucide-react';
import { useWallet } from '../hooks/useWallet';
import { getTravelNFTContract, getWeb3Provider } from '../utils/web3Config';

const BiometricPortal = () => {
  const [verificationStatus, setVerificationStatus] = useState('idle');
  const [scanningAnimation, setScanningAnimation] = useState(false);
  const [nftData, setNftData] = useState<any>(null);
  const { connect, connected, account } = useWallet();

  const startBiometricVerification = async () => {
    setScanningAnimation(true);
    setVerificationStatus('scanning');
    
    try {
      // Simulate biometric scanning
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // After successful biometric verification, fetch NFT data
      if (connected && account) {
        const provider = await getWeb3Provider();
        const contract = getTravelNFTContract(provider);
        
        // Here you would typically query the NFTs owned by the account
        // For demo purposes, we'll use mock data
        setNftData({
          passport: {
            valid: true,
            expiryDate: '2025-12-31',
          },
          visa: {
            valid: true,
            type: 'Tourist',
            country: 'United States',
          },
          healthRecord: {
            valid: true,
            lastUpdated: '2024-03-01',
          },
        });
      }
      
      setVerificationStatus('verified');
    } catch (error) {
      console.error('Verification failed:', error);
      setVerificationStatus('failed');
    } finally {
      setScanningAnimation(false);
    }
  };

  const evaluateEligibility = () => {
    if (!nftData) return false;
    return nftData.passport.valid && nftData.visa.valid && nftData.healthRecord.valid;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-xl p-6 max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold">Biometric Verification Portal</h2>
          <p className="text-gray-600 mt-2">
            Use biometric verification to access travel documents and verify eligibility
          </p>
        </div>

        {!connected ? (
          <div className="text-center">
            <button
              onClick={() => connect()}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
            >
              Connect Wallet
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center space-y-6">
            <div className={`relative p-8 rounded-full bg-gray-100 ${
              scanningAnimation ? 'animate-pulse' : ''
            }`}>
              <Fingerprint className={`h-20 w-20 ${
                verificationStatus === 'verified' ? 'text-green-600' : 'text-blue-600'
              }`} />
            </div>

            {verificationStatus === 'idle' && (
              <button
                onClick={startBiometricVerification}
                className="flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
              >
                <Fingerprint className="h-5 w-5" />
                <span>Start Biometric Verification</span>
              </button>
            )}

            {verificationStatus === 'scanning' && (
              <div className="text-blue-600 font-semibold">
                Scanning biometric data...
              </div>
            )}

            {verificationStatus === 'verified' && nftData && (
              <div className="space-y-4 w-full">
                <div className="flex items-center justify-center space-x-2 text-green-600">
                  <Check className="h-6 w-6" />
                  <span className="font-semibold">Verification Successful</span>
                </div>

                <div className="border rounded-lg p-4 space-y-4">
                  <h3 className="font-semibold text-lg">Travel Document Status</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-3 bg-green-100 rounded-lg">
                      <p className="font-medium">Passport</p>
                      <p className="text-green-600">Valid until {nftData.passport.expiryDate}</p>
                    </div>
                    <div className="p-3 bg-green-100 rounded-lg">
                      <p className="font-medium">Visa Status</p>
                      <p className="text-green-600">{nftData.visa.type} - {nftData.visa.country}</p>
                    </div>
                    <div className="p-3 bg-green-100 rounded-lg">
                      <p className="font-medium">Health Record</p>
                      <p className="text-green-600">Updated: {nftData.healthRecord.lastUpdated}</p>
                    </div>
                    <div className="p-3 bg-green-100 rounded-lg">
                      <p className="font-medium">Travel Eligibility</p>
                      <p className="text-green-600">{evaluateEligibility() ? 'Approved' : 'Pending'}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {verificationStatus === 'failed' && (
              <div className="text-red-600 flex items-center space-x-2">
                <AlertCircle className="h-5 w-5" />
                <span>Verification failed. Please try again.</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default BiometricPortal;