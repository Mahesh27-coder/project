export interface NFTMetadata {
  name: string;
  description: string;
  image: string;
  attributes: Array<{
    trait_type: string;
    value: string | number;
  }>;
}

export interface PassportData {
  fullName: string;
  dateOfBirth: string;
  nationality: string;
  passportNumber: string;
  issueDate: string;
  expiryDate: string;
  gender: string;
  placeOfBirth: string;
}

export interface VisaData {
  visaType: string;
  country: string;
  duration: number;
  entries: 'single' | 'multiple';
  validFrom: string;
  validUntil: string;
  visaNumber: string;
  purpose: string;
}

export interface HealthRecordData {
  vaccinations: Array<{
    name: string;
    date: string;
    validUntil: string;
  }>;
  bloodType: string;
  allergies: string[];
  medicalConditions: string[];
  lastCheckup: string;
}